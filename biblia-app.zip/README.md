# Santa Biblia · Reina-Valera 1909

La Biblia completa en español como app web instalable: lectura cómoda, búsqueda, resaltados, notas, marcadores, planes de lectura, lectura en voz alta y comparación con la King James. Funciona sin internet después de abrirla una vez.

## Publicar en GitHub Pages

1. Crea una cuenta en github.com, si no tienes una.
2. Toca **New repository**, ponle un nombre (por ejemplo `biblia`), déjalo en **Public** y créalo.
3. Toca **uploading an existing file** y arrastra **todo el contenido** de esta carpeta: `index.html`, `manifest.webmanifest`, `sw.js`, `README.md` y la carpeta `icons`. Luego toca **Commit changes**.
4. Ve a **Settings → Pages**. En *Branch* elige `main` y la carpeta `/ (root)`, y toca **Save**.
5. Espera uno o dos minutos. Tu app quedará en `https://TU-USUARIO.github.io/biblia/`.

## Instalar en Android

Abre ese enlace en Chrome, toca el menú ⋮ y elige **Instalar app** o **Agregar a pantalla principal**.

## Convertirla en APK (Google Play)

1. Entra a pwabuilder.com y pega el enlace de tu app.
2. Toca **Package for stores → Android** y descarga el paquete.
3. Para publicarla en Google Play necesitas una cuenta de desarrollador (pago único de 25 USD).

## Actualizar la app

Si cambias `index.html`, abre `sw.js` y cambia `biblia-v1` por `biblia-v2` (y así sucesivamente) para que los teléfonos descarguen la versión nueva.

## Créditos

- Texto bíblico: Reina-Valera 1909 y King James 1769, dominio público.
- Referencias cruzadas: OpenBible.info, licencia CC BY.
